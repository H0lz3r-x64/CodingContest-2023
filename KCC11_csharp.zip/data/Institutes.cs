﻿
namespace com.knapp.CodingContest.data
{
    public enum Institutes
    {
        // HTl, Schulen ...
        Altes_Gymnasium_Leoben, //
        HAK_Feldbach, //
        HTBLA_Kaindorf_Sulm, //
        HTBLuVA_Pinkafeld, //
        HTL_Bulme_Graz, //
        HTL_Leoben, //
        HTL_Rennweg_Wien, //
        HTL_Villach, //
        HTL_Weiz, //
        HTL_Wien_West, //
        Sacre_Coeur_Graz, //
        TAC_Hartberg, //

        SonstigeSchule //

        // Uni, FH ...
        , FH_Campus_02, //
        FH_Joanneum, //
        FH_Technikum_Wien, //
        FH_Wr_Neustadt, //
        Johannes_Kepler_Universitaet_Linz, //
        Montanuniversitaet, //
        TU_Graz, //
        TU_Wien, //
        Uni_Goettingen, //
        Universitaet_Klagenfurt, //
        Universitaet_Wien, //
        Sonstige

        //
        , _Knapp_
        , __REFERENCE__
    }
}
